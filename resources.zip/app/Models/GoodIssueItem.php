<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GoodIssueItem extends Model
{
    //
}
