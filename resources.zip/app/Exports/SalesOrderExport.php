<?php

namespace App\Exports;

use App\Models\SalesOrder;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class SalesOrderExport implements FromCollection, WithHeadings, WithMapping
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return SalesOrder::all();
    }

    public function headings(): array
    {
        return [
            'SO Number',
            'SO Date',
            'Customer Name',
            'Job',
            'Contract No',
            'Grand Total',
        ];
    }

    public function map($so): array
    {
        return [
            $so->so_number,
            $so->so_date,
            $so->customer_name,
            $so->job,
            $so->contract_no,
            $so->grand_total,
        ];
    }
}
