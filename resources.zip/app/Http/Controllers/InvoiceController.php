<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Piutang;
use App\Models\Product;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderItem;
use App\Models\PurchaseRequest;
use App\Models\SalesOrder;
use App\Models\SalesOrderItem;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class InvoiceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // dd('asd');
        // dd($request->all());
        if ($request->type == 'PurchaseOrder') {
            $redirect = route('purchase_orders.index');
        }else{
            $redirect = route('sales_orders.index');
        }

        DB::transaction(function () use ($request) {

            if ($request->type == 'PurchaseOrder') {
                $po = PurchaseOrder::with('items')->findOrFail($request->po_id);
                $class = PurchaseOrder::class;
                $classItem = PurchaseOrderItem::class;
            }else{
                $po = SalesOrder::with('items')->findOrFail($request->po_id);
                $class = SalesOrder::class;
                $classItem = SalesOrderItem::class;
            }

            if ($po->status === 'closed') {
                throw new \Exception('Sudah Lunas');
            }

            $top = (int) $request->top;

            $path = null; // ✅ default

            if ($request->hasFile('lampiran')) {
                $file = $request->file('lampiran');

                $ext = $file->getClientOriginalExtension();
                $name = $request->inv_number . '_' . Str::random(8) . '.' . $ext;

                $path = $file->storeAs('lampiran', $name, 'public');
            }

            $invoice = Invoice::create([
                'invoice_number' => $request->inv_number,
                'top' => $top,
                'invoice_date' => $request->inv_date,
                'jatuh_tempo' => Carbon::parse($request->inv_date)->addDays($top),
                'type' => $request->type,
                'source_type' => $class,
                'source_id' => $po->id,
                'subtotal' => 0,
                'tax' => 0,
                'grand_total' => 0,
                'lampiran' => $path,
            ]);



            $subtotal = 0;


            foreach (json_decode($request->items, true) as $poItemId => $row) {

                if ($row['qty_inv'] <= 0) continue;

                if ($request->type == 'PurchaseOrder') {
                    $poItem = PurchaseOrderItem::findOrFail($row['po_item_id']);

                }else{
                    $poItem = SalesOrderItem::findOrFail($row['po_item_id']);
                }

                $sisa = $poItem->qty - $poItem->qty_invoiced;

                if ($row['qty_inv'] > $sisa) {
                    throw new Exception('Qty invoice melebihi sisa');
                }

                // stock update
                $product = Product::findOrFail($poItem->product_id);

                if ($request->type == 'PurchaseOrder') {
                    $product->increment('qty', $row['qty_inv']);
                }else{
                    $product->increment('qty', -$row['qty_inv']);
                }

                $total = $row['qty_inv'] * $row['unit_price'];

                InvoiceItem::create([
                    'source_item_type' => $classItem,
                    'source_item_id' => $poItem->id,

                    'invoice_id' => $invoice->id,
                    // 'purchase_order_item_id' => $poItem->id,
                    'qty' => $row['qty_inv'],
                    'unit_price' => $row['unit_price'],
                    'total' => $total,
                ]);

                // update qty invoiced
                $poItem->increment('qty_invoiced', $row['qty_inv']);

                $subtotal += $total;
            }

            $tax = $subtotal * 0.11;

            $invoice->update([
                'subtotal' => $subtotal,
                'tax' => $tax,
                'grand_total' => $subtotal + $tax
            ]);

            // update status PO

            if ($request->type == 'PurchaseOrder') {
                $po = PurchaseOrder::with('items')->findOrFail($request->po_id);
                $pr = PurchaseRequest::with('items')->findOrFail($po->purchase_request_id);

                $totalOrdered = $po->items->sum('qty');
                $totalInvoiced = $po->items->sum('qty_invoiced');


                $po->update([
                    'status' => $totalInvoiced >= $totalOrdered
                    ? 'closed'
                    : 'partial'
                ]);

                $pr->update([
                    'status' => $totalInvoiced >= $totalOrdered
                        ? 'closed'
                        : 'partial'
                ]);
            }else{
                $po = SalesOrder::with('items')->findOrFail($request->po_id);

                $totalOrdered = $po->items->sum('qty');
                $totalInvoiced = $po->items->sum('qty_invoiced');


                $po->update([
                    'status' => $totalInvoiced >= $totalOrdered
                    ? 'closed'
                    : 'partial'
                ]);
            }



        });

        return response()->json([
            'success' => true,
            'message' => 'Invoice dibuat.',
            'redirect' => $redirect
        ]);
    }


    /**
     * Display the specified resource.
     */
    public function show(Invoice $invoice)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Invoice $invoice)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Invoice $invoice)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Invoice $invoice)
    {
        //
    }

    public function print(Invoice $inv)
    {
        if ($inv->type == 'PurchaseOrder') {
            $inv->load(['source', 'source.project', 'source.supplier', 'source.purchaseRequest' , 'items', 'items.sourceItem', 'items.sourceItem.product']);

            $pdf = Pdf::loadView('invoices.po-print', [
                'inv' => $inv,
            ]);

            return $pdf->stream("PO-Invoice.pdf");
        }else{
            $inv->load(['source', 'source.project', 'source.customer' , 'items', 'items.sourceItem', 'items.sourceItem.product']);

            $pdf = Pdf::loadView('invoices.so-print', [
                'inv' => $inv,
            ]);

            return $pdf->stream("SO-Invoice.pdf");
        }

    }

    public function piutangSo(Invoice $inv)
    {

        $inv->load(['piutangs']);
        // dd($inv);

        return view('invoices.so-piutang', compact('inv'));
    }

    public function piutangStore(Request $request)
    {
        // dd($request->all());
        $redirect = url('/invoices/' . $request->id . '/piutang');

        foreach ($request->items as $item => $row) {
            Piutang::create([
                'invoice_id' => $request->id,
                'date' => $row['piutang_date'],
                'amount' => $row['amount'],
                'bank' => $row['bank'],
                'note' => $row['notes'],
            ]);
        }


        return response()->json([
            'success' => true,
            'message' => 'Invoice dibuat.',
            'redirect' => $redirect
        ]);
    }
}
