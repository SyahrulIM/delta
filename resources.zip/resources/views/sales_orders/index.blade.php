@extends('layouts.app')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between">
        <h5>Sales Orders</h5>
        <a href="{{ route('sales_orders.export') }}" class="btn btn-success">
            Export Excel
        </a>
        <a href="{{ route('sales_orders.create') }}" class="btn btn-primary">+ Create</a>
    </div>

    <div class="card-body">
        <table class="table table-bordered" id="soTable">
            <thead>
                <tr>
                    <th>SO Number</th>
                    <th>Date</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th width="150">Action</th>
                </tr>
            </thead>
        </table>
    </div>
</div>
@endsection

@push('scripts')
<script src="{{ asset('mazer/assets/extensions/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('mazer/assets/extensions/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('mazer/assets/extensions/datatables.net-bs5/js/dataTables.bootstrap5.min.js') }}"></script>
<script src="{{ asset('mazer/assets/extensions/sweetalert2/sweetalert2.min.js') }}"></script>

<script>
$(function() {

    let table = $('#soTable').DataTable({
        ajax: "{{ route('sales_orders.data') }}",
        columns: [
            { data: 'so_number' },
            { data: 'so_date' },
            {
                data: 'customer_name',
                render: function(data){
                    return data ?? '-';
                }
            },
            {
                data: 'grand_total',
                render: function(data){
                    return parseInt(data).toLocaleString();
                }
            },
            {
                data: 'status',
                className: 'text-center',
                render: function(data){
                    return `<span class="badge bg-secondary">${data}</span>`;
                }
            },
            {
                data: 'id',
                render: function(id, type, row){
                    // <a href="/sales-orders/${id}/print" class="btn btn-secondary btn-sm" target="_blank">Print</a>
                    // <a href="/sales-orders/${id}" class="btn btn-info btn-sm">View</a>
                    return `
                        <a href="/sales-orders/${id}/edit" class="btn btn-warning btn-sm">Edit</a>
                        <a href="/sales-orders/so-invoice/${id}" class="btn btn-success btn-sm">Invoice</a>
                        <a href="/sales-orders/so-margin/${id}" class="btn btn-primary btn-sm">Margin</a>
                        <button class="btn btn-danger btn-sm btn-delete" data-id="${id}">Del</button>
                    `;
                },
                orderable: false,
                searchable: false
            }
        ]
    });

    // DELETE
    $(document).on('click', '.btn-delete', function () {
        let id = $(this).data('id');

        Swal.fire({
            title: "Hapus SO?",
            text: "Data tidak bisa dikembalikan!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            confirmButtonText: "Ya, hapus!"
        }).then((result) => {
            if (result.isConfirmed) {

                $.ajax({
                    url: `/sales-orders/${id}`,
                    method: "DELETE",
                    data: {
                        _token: "{{ csrf_token() }}"
                    },
                    success: function () {
                        Swal.fire("Deleted!", "SO berhasil dihapus.", "success");
                        table.ajax.reload();
                    },
                    error: function () {
                        Swal.fire("Error!", "Gagal menghapus SO", "error");
                    }
                });

            }
        });
    });

});
</script>
@endpush
